'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

interface GlobalStateContextProps {
  isModalOpen: boolean;
  toggleModal: () => void;
  exitMenu: () => void;
}

interface GlobalStateProviderProps {
  children: ReactNode;
}

const GlobalStateContext = createContext<GlobalStateContextProps | undefined>(undefined);

export const GlobalStateProvider = ({ children }: GlobalStateProviderProps) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const toggleModal = () => setIsModalOpen(!isModalOpen);
  const exitMenu = () => setIsModalOpen(false);

  return (
    <GlobalStateContext.Provider value={{ isModalOpen, toggleModal, exitMenu }}>
      {children}
    </GlobalStateContext.Provider>
  );
};

export const useGlobalState = () => {
  const context = useContext(GlobalStateContext);
  if (!context) {
    throw new Error('useGlobalState must be used within a GlobalStateProvider');
  }
  return context;
};
