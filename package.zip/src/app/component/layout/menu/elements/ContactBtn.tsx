'use client';

import { useGlobalState } from '@/contexts/GlobalStateContext';

interface ContactBtnProps {
  title: string;
}

const ContactBtn: React.FC<ContactBtnProps> = ({ title }) => {
  const { toggleModal, exitMenu } = useGlobalState();

  const handleClick = () => {
    exitMenu();
    toggleModal();
  };

  return (
    <button className="flex items-center cursor-pointer">
      <div
        aria-label={title}
        className="transition ease-in-out duration-300 text-center border-2 border-white rounded-3xl px-3 py-1 hover:bg-white hover:text-black"
        onClick={handleClick}
      >
        {title}
      </div>
    </button>
  );
};

export default ContactBtn;
